from fastmcp import FastMCP
from typing import List, Optional, Dict
import random
import time
import uuid
import logging

# --- Logging Configuration ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("DellServer")

# Initialize FastMCP Server
mcp = FastMCP("DellCommerce")

# --- Mock Data ---

PRODUCT_CATALOG = [
    # Laptops - XPS
    {"id": "xps-13-plus", "name": "XPS 13 Plus Laptop", "category": "Laptops", "price": 1299.00, "specs": "13.4 OLED, Intel Core i7-1360P, 16GB RAM, 512GB SSD", "image_url": "images/xps_13_laptop.png",
     "details": {"processor": "Intel Core i7-1360P (12 cores)", "os": "Windows 11 Home", "graphics": "Intel Iris Xe Graphics", "memory": "16 GB, LPDDR5, 6000 MHz", "storage": "512 GB, M.2, PCIe NVMe, SSD", "display": "13.4-inch OLED 3.5K (3456x2160) InfinityEdge Touch", "battery": "3-Cell, 55 Wh, Integrated", "weight": "2.71 lbs (1.23 kg)", "ports": "2 x Thunderbolt 4 (USB Type-C with DisplayPort and Power Delivery)"}},
    {"id": "xps-15", "name": "XPS 15 Laptop", "category": "Laptops", "price": 1499.00, "specs": "15.6 FHD+, Intel Core i7-13700H, 16GB RAM, 1TB SSD, RTX 4050", "image_url": "images/xps_13_laptop.png",
     "details": {"processor": "Intel Core i7-13700H (14 cores)", "os": "Windows 11 Home", "graphics": "NVIDIA GeForce RTX 4050, 6 GB GDDR6", "memory": "16 GB, DDR5, 4800 MHz", "storage": "1 TB, M.2, PCIe NVMe, SSD", "display": "15.6-inch FHD+ (1920 x 1200) InfinityEdge Non-Touch Anti-Glare 500-Nit", "battery": "6-Cell, 86 Wh, Integrated", "weight": "4.21 lbs (1.86 kg)", "ports": "1 x USB 3.2 Gen 2 Type-C (with DisplayPort and PowerDelivery), 2 x Thunderbolt 4 (USB Type-C)"}},
    {"id": "xps-17", "name": "XPS 17 Laptop", "category": "Laptops", "price": 2499.00, "specs": "17.0 UHD+, Intel Core i9-13900H, 32GB RAM, 1TB SSD, RTX 4070", "image_url": "images/xps_13_laptop.png",
     "details": {"processor": "Intel Core i9-13900H (14 cores)", "os": "Windows 11 Pro", "graphics": "NVIDIA GeForce RTX 4070, 8 GB GDDR6", "memory": "32 GB, DDR5, 4800 MHz", "storage": "1 TB, M.2, PCIe NVMe, SSD", "display": "17.0-inch UHD+ (3840 x 2400) InfinityEdge Touch Anti-Reflecitve 500-Nit", "battery": "6-Cell, 97 Wh, Integrated", "weight": "5.37 lbs (2.44 kg)", "ports": "4 x Thunderbolt 4 (USB Type-C with DisplayPort and Power Delivery)"}},
    
    # Laptops - Alienware
    {"id": "alienware-m16", "name": "Alienware m16 Gaming Laptop", "category": "Laptops", "price": 1799.00, "specs": "16.0 QHD+, AMD Ryzen 9 7845HX, 16GB RAM, 1TB SSD, RTX 4070", "image_url": "images/alienware_laptop.png",
     "details": {"processor": "AMD Ryzen 9 7845HX (12 cores)", "os": "Windows 11 Home", "graphics": "NVIDIA GeForce RTX 4070, 8 GB GDDR6", "memory": "16 GB, DDR5, 4800 MHz", "storage": "1 TB, M.2, PCIe NVMe, SSD", "display": "16-inch QHD+ (2560 x 1600) 165Hz, 3ms, ComfortView Plus, NVIDIA G-SYNC + DDS, 100% sRGB", "battery": "6-Cell, 86 Wh, Integrated", "weight": "7.17 lbs (3.25 kg)", "ports": "2 x Type-C (USB 3.2 Gen 2), 1 x Type-A (USB 3.2 Gen 1), 1 x HDMI 2.1"}},
    {"id": "alienware-x14", "name": "Alienware x14 R2 Gaming Laptop", "category": "Laptops", "price": 1499.00, "specs": "14.0 QHD+, Intel Core i7-13620H, 16GB RAM, 1TB SSD, RTX 4060", "image_url": "images/alienware_laptop.png",
     "details": {"processor": "Intel Core i7-13620H (10 cores)", "os": "Windows 11 Home", "graphics": "NVIDIA GeForce RTX 4060, 8 GB GDDR6", "memory": "16 GB, LPDDR5, 4800 MHz", "storage": "1 TB, M.2, PCIe NVMe, SSD", "display": "14-inch QHD+ (2560 x 1600) 165Hz, 3ms, 100% DCI-P3", "battery": "6-Cell, 80 Wh, Integrated", "weight": "4.20 lbs (1.91 kg)", "ports": "1 x USB 3.2 Gen 2 Type-C, 2 x Thunderbolt 4, 1 x HDMI 2.1, 1 x USB 3.2 Gen 1 Type-A"}},
    {"id": "alienware-m18", "name": "Alienware m18 Gaming Laptop", "category": "Laptops", "price": 2199.00, "specs": "18.0 QHD+, Intel Core i9-13900HX, 32GB RAM, 1TB SSD, RTX 4080", "image_url": "images/alienware_laptop.png",
     "details": {"processor": "Intel Core i9-13900HX (24 cores)", "os": "Windows 11 Pro", "graphics": "NVIDIA GeForce RTX 4080, 12 GB GDDR6", "memory": "32 GB, DDR5, 4800 MHz", "storage": "1 TB, M.2, PCIe NVMe, SSD", "display": "18-inch QHD+ (2560 x 1600) 165Hz, 3ms, ComfortView Plus, NVIDIA G-SYNC + DDS, 100% DCI-P3", "battery": "6-Cell, 97 Wh, Integrated", "weight": "8.90 lbs (4.04 kg)", "ports": "3 x USB 3.2 Gen 1 Type-A, 3 x USB 3.2 Gen 2 Type-C, 1 x RJ45 Ethernet, 1 x HDMI 2.1"}},

    # Laptops - Inspiron & Latitude
    {"id": "inspiron-15", "name": "Inspiron 15 Laptop", "category": "Laptops", "price": 499.00, "specs": "15.6 FHD, Intel Core i5-1235U, 8GB RAM, 512GB SSD", "image_url": "images/xps_13_laptop.png",
     "details": {"processor": "Intel Core i5-1235U (10 cores)", "os": "Windows 11 Home", "graphics": "Intel UHD Graphics", "memory": "8 GB, DDR4, 2666 MHz", "storage": "512 GB, M.2, PCIe NVMe, SSD", "display": "15.6-inch FHD (1920 x 1080) Anti-Glare LED Backlight Non-Touch Narrow Border WVA", "battery": "3-Cell, 41 Wh, Integrated", "weight": "3.65 lbs (1.66 kg)", "ports": "2 x USB 3.2 Gen 1, 1 x USB 2.0, 1 x HDMI 1.4"}},
    {"id": "inspiron-14", "name": "Inspiron 14 2-in-1 Laptop", "category": "Laptops", "price": 649.00, "specs": "14.0 FHD+ Touch, AMD Ryzen 7 7730U, 16GB RAM, 1TB SSD", "image_url": "images/xps_13_laptop.png",
     "details": {"processor": "AMD Ryzen 7 7730U (8 cores)", "os": "Windows 11 Home", "graphics": "AMD Radeon Graphics", "memory": "16 GB, LPDDR4x, 4266 MHz", "storage": "1 TB, M.2, PCIe NVMe, SSD", "display": "14.0-inch FHD+ (1920 x 1200) Truelife Touch Narrow Border WVA Display with Active Pen Support", "battery": "4-Cell, 54 Wh, Integrated", "weight": "3.46 lbs (1.57 kg)", "ports": "1 x USB 3.2 Gen 2 Type-C, 2 x USB 3.2 Gen 1 Type-A, 1 x HDMI 1.4"}},
    {"id": "latitude-7440", "name": "Latitude 7440 Laptop", "category": "Laptops", "price": 1659.00, "specs": "14.0 FHD+, Intel Core i7-1365U, 32GB RAM, 512GB SSD", "image_url": "images/xps_13_laptop.png",
     "details": {"processor": "Intel Core i7-1365U (10 cores)", "os": "Windows 11 Pro", "graphics": "Intel Iris Xe Graphics", "memory": "32 GB, LPDDR5, 4800 MHz", "storage": "512 GB, M.2, PCIe NVMe, SSD", "display": "14.0-inch FHD+ (1920 x 1200) AG, Non-Touch, IPS, 250 nits, FHD Cam, WLAN", "battery": "3-Cell, 57 Wh, Integrated", "weight": "2.93 lbs (1.33 kg)", "ports": "2 x Thunderbolt 4, 2 x USB 3.2 Gen 1, 1 x HDMI 2.0"}},

    # Desktops
    {"id": "inspiron-desktop", "name": "Inspiron Desktop", "category": "Desktops", "price": 599.00, "specs": "Intel Core i5-13400, 12GB RAM, 512GB SSD", "image_url": "images/inspiron_desktop.png",
     "details": {"processor": "Intel Core i5-13400 (10 cores)", "os": "Windows 11 Home", "graphics": "Intel UHD Graphics 730", "memory": "12 GB, DDR4, 3200 MHz", "storage": "512 GB, M.2, PCIe NVMe, SSD", "chassis": "14.7L Compact Tower", "power": "180W PSU Green", "ports": "4 x USB 2.0, 4 x USB 3.2 Gen 1, 1 x HDMI 1.4b, 1 x DisplayPort 1.4"}},
    {"id": "xps-desktop", "name": "XPS Desktop", "category": "Desktops", "price": 1099.00, "specs": "Intel Core i7-13700, 16GB RAM, 512GB SSD, RTX 3050", "image_url": "images/inspiron_desktop.png",
     "details": {"processor": "Intel Core i7-13700 (16 cores)", "os": "Windows 11 Home", "graphics": "NVIDIA GeForce RTX 3050, 8 GB GDDR6", "memory": "16 GB, DDR5, 4800 MHz", "storage": "512 GB, M.2, PCIe NVMe, SSD", "chassis": "27.1L Graphite", "power": "460W Bronze", "ports": "5 x USB 3.2 Gen 1, 2 x USB 3.2 Gen 2 Type-C, 2 x USB 2.0"}},
    {"id": "alienware-aurora", "name": "Alienware Aurora R16", "category": "Desktops", "price": 1599.00, "specs": "Intel Core i7-14700F, 32GB RAM, 1TB SSD, RTX 4060 Ti", "image_url": "images/alienware_laptop.png",
     "details": {"processor": "Intel Core i7-14700F (20 cores)", "os": "Windows 11 Home", "graphics": "NVIDIA GeForce RTX 4060 Ti, 8 GB GDDR6", "memory": "32 GB, DDR5, 5600 MHz", "storage": "1 TB, M.2, PCIe NVMe, SSD", "cooling": "240mm Liquid Cooling", "chassis": "Basalt Black with Clear Side Panel", "ports": "4 x USB 2.0, 5 x USB 3.2 Gen 1, 2 x USB 3.2 Gen 2 Type-C"}},
    {"id": "optiplex-tower", "name": "OptiPlex Tower 7020", "category": "Desktops", "price": 859.00, "specs": "Intel Core i5-14500, 16GB RAM, 256GB SSD", "image_url": "images/inspiron_desktop.png",
     "details": {"processor": "Intel Core i5-14500 (14 cores)", "os": "Windows 11 Pro", "graphics": "Intel UHD Graphics 770", "memory": "16 GB, DDR5", "storage": "256 GB, M.2 2230, PCIe NVMe, SSD, Class 35", "chassis": "Plus Tower", "security": "TPM 2.0, Lock slot", "ports": "1 x USB 3.2 Gen 2x2 Type-C, 3 x USB 3.2 Gen 1, 2 x USB 2.0, 3 x DisplayPort 1.4a"}},

    # Monitors
    {"id": "ultrasharp-27", "name": "Dell UltraSharp 27 Monitor - U2724D", "category": "Monitors", "price": 379.00, "specs": "27-inch QHD, IPS Black Technology, 120Hz", "image_url": "images/ultrasharp_monitor.png",
     "details": {"panel_type": "IPS Black Technology", "resolution": "QHD 2560 x 1440 at 120 Hz", "brightness": "350 cd/m2", "contrast_ratio": "2000:1", "color_gamut": "100% sRGB, 98% DCI-P3", "response_time": "8 ms (normal); 5 ms (fast)", "ports": "1 x DisplayPort 1.4, 1 x HDMI 2.1, 1 x Thunderbolt 4 upstream, 1 x Thunderbolt 4 downstream"}},
    {"id": "ultrasharp-32", "name": "Dell UltraSharp 32 6K Monitor - U3224KB", "category": "Monitors", "price": 2399.00, "specs": "32-inch 6K, IPS Black, Built-in 4K Webcam", "image_url": "images/ultrasharp_monitor.png",
     "details": {"panel_type": "IPS Black Technology", "resolution": "6K 6144 x 3456 at 60 Hz", "brightness": "450 cd/m2", "contrast_ratio": "2000:1", "webcam": "4K Sony Starvis CMOS sensor", "speakers": "2 x 14W", "ports": "1 x Mini DisplayPort 2.1, 1 x HDMI 2.1, 1 x Thunderbolt 4"}},
    {"id": "alienware-34-curved", "name": "Alienware 34 Curved QD-OLED Gaming Monitor", "category": "Monitors", "price": 899.00, "specs": "34-inch WQHD, 165Hz, 0.1ms, AMD FreeSync Premium Pro", "image_url": "images/ultrasharp_monitor.png",
     "details": {"panel_type": "QD-OLED", "resolution": "WQHD 3440 x 1440 at 165 Hz", "brightness": "250 cd/m2 (typical); 1000 cd/m2 (peak)", "contrast_ratio": "1M: 1", "response_time": "0.1 ms (gray-to-gray)", "curved": "Yes (1800R)", "ports": "2 x HDMI, 1 x DisplayPort 1.4"}},
    {"id": "dell-24", "name": "Dell 24 Monitor - S2421HN", "category": "Monitors", "price": 119.00, "specs": "23.8-inch FHD, 75Hz, AMD FreeSync", "image_url": "images/ultrasharp_monitor.png",
     "details": {"panel_type": "IPS", "resolution": "FHD 1920 x 1080 at 75 Hz", "brightness": "250 cd/m2", "contrast_ratio": "1000:1", "adaptive_sync": "AMD FreeSync", "ports": "2 x HDMI 1.4, 1 x Audio line-out"}},

    # Accessories
    {"id": "km-premier", "name": "Dell Premier Multi-Device Wireless Keyboard and Mouse", "category": "Accessories", "price": 89.99, "specs": "Bluetooth 5.0, 2.4GHz, 36 Months Battery", "image_url": "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/peripherals/input-devices/dell/keyboards/km7321w/global/spin/dell-pro-wireless-keyboard-and-mouse-km7321w-gy-spin-01.jpg?fmt=png-alpha&wid=570&hei=400",
     "details": {"connectivity": "Wireless - 2.4 GHz, Bluetooth 5.0", "battery_life": "Up to 36 months", "color": "Titan gray", "keyboard_features": "Programmable keys, tilt legs", "mouse_features": "7 programmable buttons, 16000 DPI"}},
    {"id": "headset-wl5022", "name": "Dell Pro Wireless Headset - WL5022", "category": "Accessories", "price": 159.99, "specs": "Teams Certified, ANC, Bluetooth", "image_url": "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/electronics-and-accessories/audio/headsets/dell/wl5022/media-gallery/audio-headset-dell-wl5022-gallery-1.psd?fmt=png-alpha&wid=570&hei=400",
     "details": {"connectivity": "Bluetooth, USB receiver", "audio_output": "Stereo", "active_noise_cancelling": "Yes", "battery_life": "Up to 15 hours", "controls": "Mute, volume, answer/end, rejection"}},
    {"id": "dock-wd19s", "name": "Dell Dock - WD19S 130W", "category": "Accessories", "price": 209.99, "specs": "USB-C, HDMI, DisplayPort, 130W Power Delivery", "image_url": "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/peripherals/docking/wd19s-130w/media-gallery/peripherals-docking-wd19s-130w-gallery-1.psd?fmt=png-alpha&wid=570&hei=400",
     "details": {"docking_interface": "USB-C", "video_interfaces": "HDMI, 2 x DP, USB-C", "power_delivery": "130 Watt", "networking": "Gigabit Ethernet", "dimensions": "8.1 in x 3.5 in x 1.1 in"}},
    {"id": "briefcase-pro", "name": "Dell Pro Briefcase 15", "category": "Accessories", "price": 49.99, "specs": "Fits 15-inch Laptop, Water Persistent", "image_url": "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/electronics-and-accessories/carrying-cases/po1520c/media-gallery/carrying-cases-dell-po1520c-gallery-1.psd?fmt=png-alpha&wid=570&hei=400",
     "details": {"product_type": "Notebook carrying case", "color": "Black", "notebook_compatibility": "15-inch", "features": "Water resistant, foam padding, padded handles, adjustable shoulder strap", "material": "1680D ballistic polyester"}},
]

ORDERS_DB: Dict[str, Dict] = {}


# --- Endpoints ---

@mcp.tool()
def get_product_catalogue(query: str = None, category: str = None) -> List[Dict]:
    """
    Retrieve products from the catalogue. CAN filter by search query and/or category.
    At least one filter (query or category) is recommended but not required.
    
    Args:
        query: Optional search text to filter by product name or description.
        category: Optional category to filter (Laptops, Desktops, Monitors, Accessories).
    """
    logger.info(f"get_product_catalogue called with query='{query}', category='{category}'")
    time.sleep(0.5) # Simulate network latency
    
    # Exclude 'details' from the summary list
    results = [
        {k: v for k, v in p.items() if k != "details"}
        for p in PRODUCT_CATALOG
    ]

    if category:
        results = [p for p in results if p["category"].lower() == category.lower()]
    
    if query:
        q = query.lower()
        results = [p for p in results if q in p["name"].lower() or q in p["specs"].lower()]

    logger.info(f"get_product_catalogue returning {len(results)} items")
    return results

@mcp.tool()
def get_product_details(product_id: str) -> Dict:
    """
    Retrieve full technical details for a specific product.
    Use this to compare products or answer detailed questions about specs/compatibility.
    
    Args:
        product_id: The unique ID of the product.
    """
    logger.info(f"get_product_details called for product_id='{product_id}'")
    product = next((p for p in PRODUCT_CATALOG if p["id"] == product_id), None)
    
    if not product:
        logger.warning(f"get_product_details: Product {product_id} not found")
        return {"error": "Product not found"}
        
    return product

@mcp.tool()
def submit_purchase_order(product_id: str, quantity: int = 1) -> Dict:
    """
    Submit a purchase order for a selected product.
    
    Args:
        product_id: The ID of the product to purchase.
        quantity: The number of units to purchase (default 1).
    """
    logger.info(f"submit_purchase_order called for product_id='{product_id}', quantity={quantity}")
    product = next((p for p in PRODUCT_CATALOG if p["id"] == product_id), None)
    if not product:
        logger.error(f"submit_purchase_order failed: Product {product_id} not found")
        return {"error": "Product not found"}
    
    order_no = f"ORD-{int(time.time())}-{random.randint(1000, 9999)}"
    total_price = product["price"] * quantity
    
    order = {
        "order_no": order_no,
        "product_name": product["name"],
        "product_id": product["id"],
        "quantity": quantity,
        "total_price": total_price,
        "status": "Processing",
        "order_time": time.time()
    }
    
    ORDERS_DB[order_no] = order
    logger.info(f"Order created successfully: {order_no}")
    return order

@mcp.tool()
def get_order_status(order_no: str) -> Dict:
    """
    Retrieve the current status of an order.
    
    Args:
        order_no: The unique order number provided at checkout.
    """
    logger.info(f"get_order_status called for order_no='{order_no}'")
    order = ORDERS_DB.get(order_no)
    if not order:
        logger.warning(f"get_order_status: Order {order_no} not found")
        return {"error": "Order not found"}
    
    # Simulate status progression based on time elapsed
    elapsed = time.time() - order["order_time"]
    if elapsed > 60:
        order["status"] = "Delivered"
    elif elapsed > 30:
        order["status"] = "Out for Delivery"
    elif elapsed > 10:
        order["status"] = "Shipped"
    
    logger.info(f"Order status for {order_no}: {order['status']}")
    return {
        "order_no": order["order_no"],
        "product": order["product_name"],
        "status": order["status"],
        "total": f"${order['total_price']:.2f}"
    }

if __name__ == "__main__":
    # Initialize the server
    logger.info("Starting DellCommerce MCP Server on port 8601...")
    mcp.run(transport='sse', port=8601)

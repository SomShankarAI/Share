# Agentic E-commerce Application

A Python-based AI agent application simulating a Dell e-commerce experience. It consists of a FastMCP server managing a product catalog and order system, and a Streamlit-based chatbot client powered by LangChain and OpenAI.

## Components

- **Server (`server.py`)**: Built with FastMCP.
  - Hosts product catalog (Laptops, Desktops, Monitors, Accessories).
  - Handles purchase orders and status checks.
  - Implements server-side filtering for search queries.

- **Client (`client.py`)**: Built with Streamlit.
  - Provides a Dell-inspired chatbot interface.
  - Connects to OpenAI via LangChain.
  - Uses MCP tools to interact with the server.
  - Displays rich product cards and images.

## Prerequisites

- Python 3.10+
- OpenAI API Key

## Setup

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure Environment**
   - Rename `.env.example` to `.env`
   - Add your OpenAI API Key:
     ```
     OPENAI_API_KEY=sk-proj-your-key-here
     ```

## Running the Application

You need to run both the server and the client components. The server uses FastMCP with SSE transport, and the client connects to it.

1. **Start the Server:**

   Open a terminal and run:
   ```bash
   python server/server.py
   ```
   The server will start on port 8601.

2. **Start the Client:**

   Open a new terminal and run:
   ```bash
   cd client
   streamlit run client.py
   ```

## Logging

Both the client and server applications are configured with detailed logging to help with debugging and monitoring. 

- **Console Output**: Logs are printed directly to the console (stdout/stderr).
- **Format**: `%(asctime)s - %(name)s - %(levelname)s - %(message)s`
- **Levels**: INFO level is enabled by default to track tool calls, API interactions, and mock data generation.

## Features

- **Product Search**: Ask "Show me XPS laptops" or "I need a gaming monitor".
- **Ordering**: "I want to buy the XPS 13" (Agent will generate an order).
- **Status Check**: "Where is my order ORD-12345?"
- **Visuals**: Displays generated product images in a responsive grid.

## Project Structure

- `server/server.py`: FastMCP server implementation.
- `client/client.py`: Streamlit frontend and LLM logic.
- `client/images/`: Generated product images.
- `requirements.txt`: Python dependencies.

import streamlit as st
import asyncio
import os
from typing import List, Dict, Any
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
from langchain_core.tools import tool
from mcp import ClientSession
# from mcp.client.stdio import stdio_client # Removed

import json
import logging

# --- Logging Configuration ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("DellClient")

# Load environment variables
load_dotenv()

# Define Base Directory for Static Files
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# --- Configuration & Styling ---

st.set_page_config(
    page_title="Dell Technologies | Official Site",
    page_icon="💻",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for Dell-like aesthetic
st.markdown("""
<style>
    /* Dell Blue: #007DB8 */
    :root {
        --dell-blue: #007DB8;
        --dell-gray: #444444;
        --light-gray: #f2f2f2;
    }
    
    .main-header {
        background-color: white;
        padding: 1rem;
        border-bottom: 2px solid var(--dell-blue);
        color: var(--dell-blue);
        font-family: 'Roboto', sans-serif;
        font-weight: 700;
        font-size: 24px;
        margin-bottom: 2rem;
    }
    
    .product-card {
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 15px;
        margin-bottom: 20px;
        background-color: var(--dell-blue);
        transition: box-shadow 0.3s ease;
    }
    
    .product-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .price-tag {
        color: var(--dell-blue);
        font-weight: bold;
        font-size: 1.2rem;
        margin-top: 10px;
    }

    .stButton>button {
        background-color: var(--dell-blue);
        color: white;
        border-radius: 4px;
        border: none;
        padding: 0.5rem 1rem;
    }
    
    .stButton>button:hover {
        background-color: #006090;
    }
    
    /* Chat bubbles */
    .chat-message {
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1rem;
        line-height: 1.5;
    }
    
    .user-message {
        background-color: var(--light-gray);
        color: var(--dell-gray);
        border-left: 4px solid var(--dell-gray);
    }
    
    .assistant-message {
        background-color: #e6f4f9; /* Light blue tint */
        color: #333;
        border-left: 4px solid var(--dell-blue);
    }
    
</style>
""", unsafe_allow_html=True)

# --- Helper Functions ---

def get_llm():
    """Retrieve the ChatOpenAI instance as requested."""
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        st.error("OPENAI_API_KEY not found in environment variables. Please set it in .env file.")
        st.stop()
    return ChatOpenAI(model="gpt-4", temperature=0, api_key=api_key)

from mcp.client.sse import sse_client

async def run_mcp_tool(tool_name: str, arguments: dict):
    """Execute a tool on the MCP server via SSE."""
    # Connect to the local SSE server
    # Note: FastMCP usually mounts SSE at /sse. If not, we can try /.
    url = "http://localhost:8601/sse"

    logger.info(f"Connecting to SSE server at {url} for tool '{tool_name}' with args {arguments}")
    try:
        async with sse_client(url) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(tool_name, arguments)
                logger.info(f"Tool '{tool_name}' executed successfully.")
                return result
    except Exception as e:
        logger.error(f"Failed to execute tool '{tool_name}': {e}")
        raise e

# --- Session State Management ---

if "messages" not in st.session_state:
    st.session_state.messages = []

if "order_confirmed" not in st.session_state:
    st.session_state.order_confirmed = None

# --- UI Components ---

def render_header():
    st.markdown('<div class="main-header">DELL Technologies <span style="font-weight:400; color:#444; font-size:18px; margin-left:10px;">| AI Assistant</span></div>', unsafe_allow_html=True)

def display_product_card(product: dict):
    """Render a single product card."""
    with st.container():
        st.markdown(f"""
        <div class="product-card">
            <h4>{product['name']}</h4>
        </div>
        """, unsafe_allow_html=True)
        
        cols = st.columns([1, 2])
        with cols[0]:
            image_url = product['image_url']
            
            # 1. Check if it's a remote URL
            if image_url.startswith(("http://", "https://")):
                st.image(image_url, width="stretch")
            
            # 2. Check if it's a local file (resolve relative to client.py)
            else:
                 local_path = os.path.join(BASE_DIR, image_url)
                 logger.info(f"Local path: {local_path}")
                 if os.path.exists(local_path):
                     st.image(local_path, width="stretch")
                 # 3. Fallback: check CWD or other paths
                 elif os.path.exists(image_url):
                     st.image(image_url, width="stretch")
                 else:
                     st.image("https://via.placeholder.com/300x200?text=Dell+Product", width="stretch")
        
        with cols[1]:
            st.markdown(f"**Specs:** {product['specs']}")
            st.markdown(f"**Category:** {product['category']}")
            st.markdown(f"<div class='price-tag'>${product['price']:.2f}</div>", unsafe_allow_html=True)
            
            # Button callback wrapper (streamlining button interactions if needed)
            #if st.button("Buy Now", key=f"buy_{product['id']}"):
            #     return product['id']
    return None

def process_tool_calls(tool_calls, messages):
    """Mock executing tool calls locally and returning results."""
    # Note: In a real async environment with MCP properly bound to LangChain, this would be cleaner.
    # Here we are manually bridging them for the POC.
    
    results = []
    for tool_call in tool_calls:
        tool_name = tool_call["name"]
        args = tool_call["args"]
        tool_call_id = tool_call["id"]
        
        content = None
        
        # We need to bridge the async mcp call to sync streamlit
        # Using a loop just for this call
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            mcp_result = loop.run_until_complete(run_mcp_tool(tool_name, args))
            loop.close()
            
            # Parse MCP result content
            # MCP returns a list of content items (text or image)
            # We assume text for now
            if mcp_result.content:
                 content = mcp_result.content[0].text
            else:
                 content = "{}"
                 
            # If product catalog, try to render it prettily in the chat?
            # Or just return data to LLM to summarize
            
        except Exception as e:
            content = f"Error executing tool {tool_name}: {str(e)}"

        results.append(ToolMessage(tool_call_id=tool_call_id, content=str(content), name=tool_name))
        
        # Side effect: If it's the product catalog, we might want to display it visually in the UI
        # But for now, let the LLM describe it / or we can parse the content JSON
        if tool_name == "get_product_catalogue":
            try:
                products = eval(content) # Safe enough for our mock mock data
                if isinstance(products, list) and len(products) > 0:
                    st.session_state.last_products = products
            except:
                pass
                
    return results

# --- Main App Logic ---

render_header()

# Sidebar
with st.sidebar:
    st.header("Assistance")
    st.info("I can help you browse products, place orders, and check order status.")
    
    if st.button("Clear Chat"):
        st.session_state.messages = []
        if "last_products" in st.session_state:
            del st.session_state.last_products
        st.rerun()

# Chat Area
chat_container = st.container()

# Input
user_input = st.chat_input("How can I help you today?")

if user_input:
    # Add user message
    logger.info(f"User Input: {user_input}")
    
    # Reset product view on new query
    if "last_products" in st.session_state:
        del st.session_state.last_products
        
    st.session_state.messages.append(HumanMessage(content=user_input))
    
    # Get LLM response
    llm = get_llm()
    
    # Define Tools Schema for LLM (Manually defining for OpenAI binding since we aren't dynamically loading them yet)
    # Ideally we'd reflectively get this from MCP, but for POC we hardcode the signature matching server.py
    tools = [
        {
            "type": "function",
            "function": {
                "name": "get_product_catalogue",
                "description": "Retrieve products from the catalogue. CAN filter by search query and/or category. Returns a list of products.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search text to filter by product name or description."},
                        "category": {"type": "string", "description": "Category to filter (Laptops, Desktops, Monitors, Accessories)."}
                    },
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_product_details",
                "description": "Retrieve full technical details for a specific product. Use this to compare products or answer detailed questions about specs/compatibility.",
                "parameters": {
                     "type": "object",
                     "properties": {
                         "product_id": {"type": "string", "description": "The ID of the product."}
                     },
                     "required": ["product_id"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "submit_purchase_order",
                "description": "Submit a purchase order for a selected product.",
                "parameters": {
                     "type": "object",
                     "properties": {
                         "product_id": {"type": "string", "description": "The ID of the product to purchase."},
                         "quantity": {"type": "integer", "description": "The number of units to purchase."}
                     },
                     "required": ["product_id"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_order_status",
                "description": "Retrieve the current status of an order.",
                "parameters": {
                     "type": "object",
                     "properties": {
                         "order_no": {"type": "string", "description": "The order number."}
                     },
                     "required": ["order_no"]
                }
            }
        }
    ]
    
    llm_with_tools = llm.bind_tools(tools)
    
    with st.spinner("Thinking..."):
        # 1. First Call
        response = llm_with_tools.invoke(st.session_state.messages)
        logger.info(f"LLM Response (First Call): Content='{response.content}', ToolCalls={len(response.tool_calls)}")
        st.session_state.messages.append(response)
        
        # 2. Check for tool calls
        if response.tool_calls:
            tool_outputs = process_tool_calls(response.tool_calls, st.session_state.messages)
            st.session_state.messages.extend(tool_outputs)
            
            # 3. Second Call (with tool outputs)
            final_response = llm_with_tools.invoke(st.session_state.messages)
            logger.info(f"LLM Response (Final): {final_response.content}")
            st.session_state.messages.append(final_response)

# Display Chat History
with chat_container:
    for msg in st.session_state.messages:
        if isinstance(msg, HumanMessage):
            st.markdown(f'<div class="chat-message user-message">{msg.content}</div>', unsafe_allow_html=True)
        elif isinstance(msg, AIMessage):
            content = msg.content
            if not content and msg.tool_calls:
                 pass # Skip empty tool call initiation messages if you want
            else:
                st.markdown(f'<div class="chat-message assistant-message">{content}</div>', unsafe_allow_html=True)
            
            # Special handling: If we have product data in session state (from a recent tool call), show grid
            # This is a bit disjointed, but effectively mimics "Showing content"
            # We clear it after showing? Or keep it?
            # Let's show it if it's the last message
            if msg == st.session_state.messages[-1] and "last_products" in st.session_state:
                st.subheader("Featured Products")
                products = st.session_state.last_products
                
                # Create grid
                cols_per_row = 3
                for i in range(0, len(products), cols_per_row):
                    row_cols = st.columns(cols_per_row)
                    for j in range(cols_per_row):
                        if i + j < len(products):
                            with row_cols[j]:
                                product_id = display_product_card(products[i+j])
                                # Note: Button handling in streamlit inside a loop is tricky without rerun
                                # For this POC, we rely on the chat to buy "I want to buy xps-13"


import sys
import os

# Ensure we can import backend
sys.path.append(os.getcwd())

from backend import ChatbotBackend

def test_backend():
    print("Initializing Backend...")
    # Mock API Key if needed or expect it in env. 
    # For test, we might fallback to error if no key, but let's see.
    if not os.environ.get("OPENAI_API_KEY"):
        print("WARNING: OPENAI_API_KEY not set. Test might fail if not using local models.")
    
    backend = ChatbotBackend()
    
    # Test Metadata Injection Logic
    # Query matching Alpha
    query = "What is the budget for Project Alpha?"
    print(f"\nTesting Metadata RAG with query: '{query}'")
    try:
        response, filename, step1 = backend.metadata_injection_response(query)
        print(f"Step 1: {step1}")
        print(f"Selected File: {filename}")
        print(f"Response: {response}")
        
        if "alpha_report.txt" in filename:
            print("PASS: Correctly identified Alpha file.")
        else:
            print("FAIL: Did not identify Alpha file.")
            
    except Exception as e:
        print(f"Metadata RAG Failed: {e}")

    # Query matching Beta
    query_beta = "What is the latency requirement for Beta?"
    print(f"\nTesting Metadata RAG with query: '{query_beta}'")
    try:
        response, filename, step1 = backend.metadata_injection_response(query_beta)
        print(f"Step 1: {step1}")
        print(f"Selected File: {filename}")
        
        if "beta_report.txt" in filename:
            print("PASS: Correctly identified Beta file.")
        else:
            print("FAIL: Did not identify Beta file.")
    except Exception as e:
        print(f"Metadata RAG Failed: {e}")

if __name__ == "__main__":
    test_backend()

import streamlit as st
import os
from backend import ChatbotBackend

st.set_page_config(layout="wide", page_title="RAG Comparison Chatbot")

st.title("RAG Comparison: Simple vs Metadata Injection")

# Sidebar for Setup
with st.sidebar:
    st.header("Configuration")
    api_key = st.text_input("OpenAI API Key", type="password")
    if api_key:
        os.environ["OPENAI_API_KEY"] = api_key
    
    if st.button("Reset/Initialize Database"):
        try:
            if "backend" in st.session_state:
                st.session_state.backend.reset_db()
                st.success("Database Reset Complete!")
            else:
                 # Try to init to reset
                 backend = ChatbotBackend(api_key=api_key)
                 backend.reset_db()
                 st.session_state.backend = backend
                 st.success("Database Created!")
        except Exception as e:
            st.error(f"Error initializing DB: {e}")

# Initialize Backend
if "backend" not in st.session_state:
    if os.environ.get("OPENAI_API_KEY"):
        try:
            st.session_state.backend = ChatbotBackend()
        except Exception as e:
            st.error(f"Backend Initialization Error: {e}")
    else:
        st.warning("Please enter OpenAI API Key to start.")
        st.stop()

# Layout
col1, col2 = st.columns(2)

# Simple RAG Column
with col1:
    st.header("Simple RAG")
    st.info("Standard retrieval across all documents.")
    
    if "history_simple" not in st.session_state:
        st.session_state.history_simple = []
        
    for msg in st.session_state.history_simple:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            
    if prompt1 := st.chat_input("Ask Simple RAG", key="chat1"):
        st.session_state.history_simple.append({"role": "user", "content": prompt1})
        with st.chat_message("user"):
            st.markdown(prompt1)
            
        with st.chat_message("assistant"):
            try:
                response = st.session_state.backend.simple_rag_response(prompt1)
                st.markdown(response)
                st.session_state.history_simple.append({"role": "assistant", "content": response})
            except Exception as e:
                st.error(f"Error: {e}")

# Metadata Injection RAG Column
with col2:
    st.header("Metadata Injection RAG")
    st.info("1. Search Taxonomy -> 2. Select File -> 3. RAG")
    
    if "history_meta" not in st.session_state:
        st.session_state.history_meta = []
        
    for msg in st.session_state.history_meta:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            
    if prompt2 := st.chat_input("Ask Metadata RAG", key="chat2"):
        st.session_state.history_meta.append({"role": "user", "content": prompt2})
        with st.chat_message("user"):
            st.markdown(prompt2)
            
        with st.chat_message("assistant"):
            try:
                response, filename, step1 = st.session_state.backend.metadata_injection_response(prompt2)
                
                # Show process details
                with st.expander("Internal Process Details"):
                    st.write(f"**Step 1 Analysis:** {step1}")
                    st.write(f"**Target File:** `{filename}`")
                
                st.markdown(response)
                st.session_state.history_meta.append({"role": "assistant", "content": response})
            except Exception as e:
                st.error(f"Error: {e}")

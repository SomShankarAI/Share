import io
import json
import pypdf
from typing import Dict
from langchain_core.messages import SystemMessage, HumanMessage
from state import AgentState, MetadataItem
from utils import get_llm, get_taxonomy_names, get_taxonomy_details

def pdf_agent(state: AgentState) -> Dict:
    print(f"Processing PDF: {state['filename']}")
    file_content = state['file_content']
    
    # Extract text from PDF
    try:
        pdf_file = io.BytesIO(file_content)
        reader = pypdf.PdfReader(pdf_file)
        text_content = ""
        for page in reader.pages:
            text_content += page.extract_text() + "\n"
    except Exception as e:
        print(f"Error reading PDF: {e}")
        text_content = "Error extraction text from PDF."

    from langchain_text_splitters import RecursiveCharacterTextSplitter
    
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=4000,
        chunk_overlap=200,
        length_function=len,
    )
    chunks = text_splitter.split_text(text_content)
    
    taxonomy_names = get_taxonomy_names()
    taxonomy_str = json.dumps(taxonomy_names, indent=2)
    
    all_metadata = []
    
    llm = get_llm()
    
    for i, chunk in enumerate(chunks):
        print(f"Processing chunk {i+1}/{len(chunks)}...")
        prompt = f"""
        You are an expert taxonomy classifier.
        Here is the list of available taxonomy names:
        {taxonomy_str}
        
        Here is a segment of text content from a PDF file named '{state['filename']}':
        {chunk}
        
        Identify ALL relevant taxonomy names from the list for this document segment.
        Return the result as a JSON object with a single key "matches", which is a list of objects.
        Each object in the list should have:
        "taxonomy": <exact name from the list>,
        "text": <snippet of the text that justifies this classification from this segment>
        
        The "node" key should be empty string.
        
        Return ONLY the JSON object.
        """
        
        messages = [
            SystemMessage(content="You are a helpful assistant that outputs JSON."),
            HumanMessage(content=prompt)
        ]
        
        try:
            response = llm.invoke(messages)
            content = response.content.strip()
            if content.startswith("```json"):
                content = content[7:]
            if content.endswith("```"):
                content = content[:-3]
                
            result = json.loads(content)
            matches = result.get("matches", [])
            if isinstance(matches, dict):
                 matches = [matches]
            
            for match in matches:
                tax_name = match.get("taxonomy", "")
                # Deduplication check could go here, but requirements just say "Identify ALL"
                # We will aggregate all findings.
                
                details = get_taxonomy_details(tax_name)
                
                tax_uri = details["taxonomy-uri"] if details else ""
                tax_hierarchy = details["taxonomy-hierarchy"] if details else ""
                
                meta_item: MetadataItem = {
                    "taxonomy": tax_name,
                    "taxonomy_uri": tax_uri,
                    "taxonomy-hierarchy": tax_hierarchy,
                    "text": match.get("text", ""),
                    "node": ""
                }
                all_metadata.append(meta_item)
                
        except Exception as e:
            print(f"Error parsing LLM response for chunk {i}: {e}")
            
    return {"metadata": all_metadata}
        


import os
import json
import shutil
from typing import List, Dict, Tuple

from langchain_core.documents import Document
from langchain_community.document_loaders import TextLoader, DirectoryLoader
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_chroma import Chroma
from langchain_text_splitters import CharacterTextSplitter
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough

DATA_DIR = "data"
TAXONOMY_FILE = "taxonomy.json"
CHROMA_PATH = "chroma_db"
COLLECTION_CONTENT = "content_collection"
COLLECTION_METADATA = "metadata_collection"

def get_llm():
    return ChatOpenAI(model="gpt-3.5-turbo", temperature=0)

class ChatbotBackend:
    def __init__(self, api_key: str = None):
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key
        
        self.embeddings = OpenAIEmbeddings()
        self.llm = get_llm()
        
        # Check if DB needs initialization
        if not os.path.exists(CHROMA_PATH):
            self.first_time_setup()
            
        self.db_content = Chroma(persist_directory=CHROMA_PATH, embedding_function=self.embeddings, collection_name=COLLECTION_CONTENT)
        self.db_metadata = Chroma(persist_directory=CHROMA_PATH, embedding_function=self.embeddings, collection_name=COLLECTION_METADATA)

    def first_time_setup(self):
        print("Initializing Database...")
        os.makedirs(CHROMA_PATH, exist_ok=True)
        
        # 1. Index Content
        self._index_content_documents()
        
        # 2. Index Metadata (Taxonomy)
        self._index_taxonomy()
        
    def _index_content_documents(self):
        loader = DirectoryLoader(DATA_DIR, glob="*.txt", loader_cls=TextLoader)
        documents = loader.load()
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        docs = text_splitter.split_documents(documents)
        
        # Ensure metadata has 'source' which usually holds the path. 
        # We need filename as 'source' to match taxonomy.
        for doc in docs:
            # Absolute path to filename only
            doc.metadata["source"] = os.path.basename(doc.metadata["source"])
            
        Chroma.from_documents(
            documents=docs,
            embedding=self.embeddings,
            persist_directory=CHROMA_PATH,
            collection_name=COLLECTION_CONTENT
        )
        print(f"Indexed {len(docs)} content chunks.")

    def _index_taxonomy(self):
        with open(TAXONOMY_FILE, 'r') as f:
            taxonomy_data = json.load(f)
            
        docs = []
        for item in taxonomy_data:
            filename = item['filename']
            for meta in item['metadata']:
                # We index the taxonomy text/description to find the filename
                # Content = taxonomy string + text description
                content = f"{meta['taxonomy']} {meta['text']} {meta['taxonomy-hierarchy']}"
                metadata = {"filename": filename, "taxonomy": meta['taxonomy']}
                docs.append(Document(page_content=content, metadata=metadata))
        
        Chroma.from_documents(
            documents=docs,
            embedding=self.embeddings,
            persist_directory=CHROMA_PATH,
            collection_name=COLLECTION_METADATA
        )
        print(f"Indexed {len(docs)} taxonomy items.")

    def simple_rag_response(self, query: str) -> str:
        """Standard RAG: Search all content documents."""
        retriever = self.db_content.as_retriever(search_kwargs={"k": 3})
        
        template = """Answer the question based only on the following context:
        {context}
        
        Question: {question}
        """
        prompt = ChatPromptTemplate.from_template(template)
        
        chain = (
            {"context": retriever, "question": RunnablePassthrough()}
            | prompt
            | self.llm
            | StrOutputParser()
        )
        
        return chain.invoke(query)

    def metadata_injection_response(self, query: str) -> Tuple[str, str, str]:
        """
        Two-step RAG:
        1. Search Metadata to find filename.
        2. RAG on selected file content.
        Returns: (Response, Filename, Step1_Thought)
        """
        # Step 1: Find Filename
        results = self.db_metadata.similarity_search(query, k=1)
        if not results:
             return "Could not identify relevant context/file from taxonomy.", "None", "No match in taxonomy."
             
        best_match = results[0]
        filename = best_match.metadata['filename']
        taxonomy_found = best_match.metadata['taxonomy']
        
        step1_info = f"Matched Taxonomy: '{taxonomy_found}' -> Selected File: '{filename}'"
        
        # Step 2: RAG on specific file
        # Using filter logic for Chroma
        retriever = self.db_content.as_retriever(
            search_kwargs={
                "k": 3,
                "filter": {"source": filename}
            }
        )
        
        template = """Answer the question based only on the following context:
        {context}
        
        Question: {question}
        """
        prompt = ChatPromptTemplate.from_template(template)
        
        chain = (
            {"context": retriever, "question": RunnablePassthrough()}
            | prompt
            | self.llm
            | StrOutputParser()
        )
        
        response = chain.invoke(query)
        return response, filename, step1_info

    def reset_db(self):
        if os.path.exists(CHROMA_PATH):
            shutil.rmtree(CHROMA_PATH)
        self.first_time_setup()

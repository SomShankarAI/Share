from typing import Dict, Any, List
from langchain.schema import BaseMessage, HumanMessage, AIMessage
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from typing_extensions import Annotated, TypedDict
import json
import logging
from ..shared.models import OnboardingState
from .mcp_client import MCPClient

logger = logging.getLogger(__name__)


class WorkflowState(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]
    onboarding_state: OnboardingState


class OnboardingWorkflow:
    def __init__(self, openai_api_key: str):
        self.llm = ChatOpenAI(
            model="gpt-3.5-turbo",
            temperature=0.1,
            openai_api_key=openai_api_key
        )
        self.mcp_client = MCPClient()
        self.workflow = self._create_workflow()
    
    def _create_workflow(self) -> StateGraph:
        """Create the LangGraph workflow"""
        workflow = StateGraph(WorkflowState)
        
        # Add nodes
        workflow.add_node("analyze_input", self._analyze_input)
        workflow.add_node("collect_store_id", self._collect_store_id)
        workflow.add_node("fetch_store_info", self._fetch_store_info)
        workflow.add_node("fetch_b2b_data", self._fetch_b2b_data)
        workflow.add_node("collect_selections", self._collect_selections)
        workflow.add_node("complete_onboarding", self._complete_onboarding)
        
        # Set entry point
        workflow.set_entry_point("analyze_input")
        
        # Add conditional edges
        workflow.add_conditional_edges(
            "analyze_input",
            self._route_next_step,
            {
                "collect_store_id": "collect_store_id",
                "fetch_store_info": "fetch_store_info",
                "fetch_b2b_data": "fetch_b2b_data",
                "collect_selections": "collect_selections",
                "complete_onboarding": "complete_onboarding",
                "end": END
            }
        )
        
        # Add edges from other nodes back to analyze_input
        for node in ["collect_store_id", "fetch_store_info", "fetch_b2b_data", "collect_selections"]:
            workflow.add_edge(node, "analyze_input")
        
        workflow.add_edge("complete_onboarding", END)
        
        return workflow.compile()
    
    def _analyze_input(self, state: WorkflowState) -> Dict[str, Any]:
        """Analyze user input and determine next step"""
        current_message = state["messages"][-1].content
        onboarding_state = state["onboarding_state"]
        
        # Create analysis prompt
        prompt = ChatPromptTemplate.from_template("""
        You are an onboarding assistant. Analyze the user's message and current state to determine what information is missing.
        
        Current onboarding state:
        - Store ID: {store_id}
        - Team Name: {team_name}
        - Profile Name: {profile_name}
        - B2B Profiles: {b2b_profiles}
        - B2B Identities: {b2b_identities}
        - Selected Profiles: {selected_profiles}
        - Selected Identities: {selected_identities}
        - Current Step: {step}
        
        User message: {message}
        
        Determine the next step based on what's missing:
        1. If no store_id: return "collect_store_id"
        2. If store_id but no team_name/profile_name: return "fetch_store_info"
        3. If store info but no b2b_profiles/identities: return "fetch_b2b_data"
        4. If b2b data but no selections made: return "collect_selections"
        5. If all data collected: return "complete_onboarding"
        6. If user wants to restart or change something: return appropriate step
        
        Return only the step name.
        """)
        
        response = self.llm.invoke(prompt.format(
            store_id=onboarding_state.store_id or "None",
            team_name=onboarding_state.team_name or "None",
            profile_name=onboarding_state.profile_name or "None",
            b2b_profiles=onboarding_state.b2b_profiles or "None",
            b2b_identities=onboarding_state.b2b_identities or "None",
            selected_profiles=onboarding_state.selected_profiles or "None",
            selected_identities=onboarding_state.selected_identities or "None",
            step=onboarding_state.step,
            message=current_message
        ))
        
        next_step = response.content.strip()
        onboarding_state.step = next_step
        
        return {"onboarding_state": onboarding_state}
    
    def _collect_store_id(self, state: WorkflowState) -> Dict[str, Any]:
        """Collect store ID from user"""
        current_message = state["messages"][-1].content
        onboarding_state = state["onboarding_state"]
        
        # Try to extract store ID from message
        prompt = ChatPromptTemplate.from_template("""
        Extract the store ID from the user's message. Look for patterns like:
        - "My store ID is ABC123"
        - "Store: XYZ789"
        - "ABC123" (if it looks like a store ID)
        
        User message: {message}
        
        If you find a store ID, return just the ID. If not found, return "NOT_FOUND".
        """)
        
        response = self.llm.invoke(prompt.format(message=current_message))
        extracted_id = response.content.strip()
        
        if extracted_id != "NOT_FOUND":
            onboarding_state.store_id = extracted_id
            ai_response = f"Great! I've recorded your Store ID as {extracted_id}. Let me fetch your team and profile information."
        else:
            ai_response = "I need your Store ID to begin the onboarding process. Could you please provide your Store ID?"
        
        state["messages"].append(AIMessage(content=ai_response))
        return {"messages": state["messages"], "onboarding_state": onboarding_state}
    
    def _fetch_store_info(self, state: WorkflowState) -> Dict[str, Any]:
        """Fetch team name and profile name using MCP tool"""
        onboarding_state = state["onboarding_state"]
        
        try:
            store_info = self.mcp_client.get_profile_and_team_name(onboarding_state.store_id)
            onboarding_state.team_name = store_info["team_name"]
            onboarding_state.profile_name = store_info["profile_name"]
            
            ai_response = f"Perfect! I found your information:\n- Team: {store_info['team_name']}\n- Profile: {store_info['profile_name']}\n\nNow let me fetch your available B2B profiles and identities."
            
        except Exception as e:
            logger.error(f"Error fetching store info: {e}")
            ai_response = f"I encountered an error fetching your store information. Please verify your Store ID: {onboarding_state.store_id}"
        
        state["messages"].append(AIMessage(content=ai_response))
        return {"messages": state["messages"], "onboarding_state": onboarding_state}
    
    def _fetch_b2b_data(self, state: WorkflowState) -> Dict[str, Any]:
        """Fetch B2B profiles and identities using MCP tool"""
        onboarding_state = state["onboarding_state"]
        
        try:
            b2b_data = self.mcp_client.get_b2b_profiles_and_identities(onboarding_state.store_id)
            onboarding_state.b2b_profiles = b2b_data["profiles"]
            onboarding_state.b2b_identities = b2b_data["identities"]
            
            profiles_list = "\n".join([f"- {profile}" for profile in b2b_data["profiles"]])
            identities_list = "\n".join([f"- {identity}" for identity in b2b_data["identities"]])
            
            ai_response = f"""I found the following B2B options for your store:

**Available B2B Profiles:**
{profiles_list}

**Available B2B Identities:**
{identities_list}

Please let me know which profiles and identities you'd like to select for your onboarding. You can say something like "I want Manufacturing Profile and Retail Profile for profiles, and Admin Identity and Manager Identity for identities"."""
            
        except Exception as e:
            logger.error(f"Error fetching B2B data: {e}")
            ai_response = "I encountered an error fetching your B2B profiles and identities. Please try again."
        
        state["messages"].append(AIMessage(content=ai_response))
        return {"messages": state["messages"], "onboarding_state": onboarding_state}
    
    def _collect_selections(self, state: WorkflowState) -> Dict[str, Any]:
        """Collect user selections for B2B profiles and identities"""
        current_message = state["messages"][-1].content
        onboarding_state = state["onboarding_state"]
        
        # Extract selections from user message
        prompt = ChatPromptTemplate.from_template("""
        Extract the selected B2B profiles and identities from the user's message.
        
        Available profiles: {available_profiles}
        Available identities: {available_identities}
        
        User message: {message}
        
        Return a JSON object with "profiles" and "identities" arrays containing the selected items.
        Only include items that are in the available lists.
        If no clear selections are made, return {{"profiles": [], "identities": []}}.
        """)
        
        response = self.llm.invoke(prompt.format(
            available_profiles=onboarding_state.b2b_profiles,
            available_identities=onboarding_state.b2b_identities,
            message=current_message
        ))
        
        try:
            selections = json.loads(response.content)
            selected_profiles = selections.get("profiles", [])
            selected_identities = selections.get("identities", [])
            
            if selected_profiles and selected_identities:
                onboarding_state.selected_profiles = selected_profiles
                onboarding_state.selected_identities = selected_identities
                
                ai_response = f"""Perfect! I've recorded your selections:

**Selected Profiles:** {', '.join(selected_profiles)}
**Selected Identities:** {', '.join(selected_identities)}

Everything looks good! Would you like me to proceed with the onboarding process?"""
            else:
                ai_response = "I couldn't identify your selections clearly. Please specify which profiles and identities you'd like to select from the available options."
        
        except json.JSONDecodeError:
            ai_response = "I had trouble understanding your selections. Please specify which profiles and identities you'd like to choose."
        
        state["messages"].append(AIMessage(content=ai_response))
        return {"messages": state["messages"], "onboarding_state": onboarding_state}
    
    def _complete_onboarding(self, state: WorkflowState) -> Dict[str, Any]:
        """Complete the onboarding process using MCP tool"""
        onboarding_state = state["onboarding_state"]
        
        try:
            result = self.mcp_client.onboard_user(
                store_id=onboarding_state.store_id,
                team_name=onboarding_state.team_name,
                profile_name=onboarding_state.profile_name,
                selected_profiles=onboarding_state.selected_profiles,
                selected_identities=onboarding_state.selected_identities
            )
            
            ai_response = f"""🎉 Onboarding completed successfully!

**Summary:**
- Store ID: {onboarding_state.store_id}
- Team: {onboarding_state.team_name}
- Profile: {onboarding_state.profile_name}
- Selected Profiles: {', '.join(onboarding_state.selected_profiles)}
- Selected Identities: {', '.join(onboarding_state.selected_identities)}

**Onboarding ID:** {result.get('onboarding_id', 'N/A')}

Your onboarding process has been initiated successfully. You should receive further instructions via email shortly."""
            
            onboarding_state.step = "completed"
            
        except Exception as e:
            logger.error(f"Error completing onboarding: {e}")
            ai_response = "I encountered an error while completing your onboarding. Please contact support for assistance."
        
        state["messages"].append(AIMessage(content=ai_response))
        return {"messages": state["messages"], "onboarding_state": onboarding_state}
    
    def _route_next_step(self, state: WorkflowState) -> str:
        """Route to the next step based on current state"""
        return state["onboarding_state"].step
    
    def process_message(self, message: str, current_state: OnboardingState) -> tuple[str, OnboardingState, bool]:
        """Process a user message and return response, updated state, and completion status"""
        initial_state = WorkflowState(
            messages=[HumanMessage(content=message)],
            onboarding_state=current_state
        )
        
        # Run the workflow
        result = self.workflow.invoke(initial_state)
        
        # Extract the AI response
        ai_messages = [msg for msg in result["messages"] if isinstance(msg, AIMessage)]
        response = ai_messages[-1].content if ai_messages else "I'm sorry, I couldn't process your request."
        
        # Check if onboarding is completed
        completed = result["onboarding_state"].step == "completed"
        
        return response, result["onboarding_state"], completed
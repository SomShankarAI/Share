import httpx
import json
import logging
from typing import Dict, List, Any

logger = logging.getLogger(__name__)


class MCPClient:
    """Client to interact with MCP Tools Server"""
    
    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url
        self.client = httpx.Client(timeout=30.0)
    
    def get_profile_and_team_name(self, store_id: str) -> Dict[str, str]:
        """Call GetProfileAndTeamNameByStoreId MCP tool"""
        try:
            # For now, we'll simulate the MCP call with direct tool usage
            # In a real implementation, this would make HTTP calls to the MCP server
            from ..mcp_server.tools import MCPTools
            return MCPTools.get_profile_and_team_name_by_store_id(store_id)
        except Exception as e:
            logger.error(f"Error calling get_profile_and_team_name: {e}")
            raise
    
    def get_b2b_profiles_and_identities(self, store_id: str) -> Dict[str, List[str]]:
        """Call GetB2BProfilesAndIdentitiesByStoreId MCP tool"""
        try:
            # For now, we'll simulate the MCP call with direct tool usage
            # In a real implementation, this would make HTTP calls to the MCP server
            from ..mcp_server.tools import MCPTools
            return MCPTools.get_b2b_profiles_and_identities_by_store_id(store_id)
        except Exception as e:
            logger.error(f"Error calling get_b2b_profiles_and_identities: {e}")
            raise
    
    def onboard_user(self, store_id: str, team_name: str, profile_name: str,
                    selected_profiles: List[str], selected_identities: List[str]) -> Dict[str, Any]:
        """Call OnboardUser MCP tool"""
        try:
            # For now, we'll simulate the MCP call with direct tool usage
            # In a real implementation, this would make HTTP calls to the MCP server
            from ..mcp_server.tools import MCPTools
            return MCPTools.onboard_user(
                store_id=store_id,
                team_name=team_name,
                profile_name=profile_name,
                selected_profiles=selected_profiles,
                selected_identities=selected_identities
            )
        except Exception as e:
            logger.error(f"Error calling onboard_user: {e}")
            raise
    
    def __del__(self):
        """Clean up HTTP client"""
        if hasattr(self, 'client'):
            self.client.close()
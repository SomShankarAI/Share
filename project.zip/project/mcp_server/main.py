import asyncio
import logging
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
from .tools import MCPTools
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create MCP server instance
server = Server("onboarding-mcp-server")

@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available MCP tools"""
    return [
        Tool(
            name="get_profile_and_team_name_by_store_id",
            description="Get team name and profile name for a given store ID",
            inputSchema={
                "type": "object",
                "properties": {
                    "store_id": {
                        "type": "string",
                        "description": "The store ID to lookup"
                    }
                },
                "required": ["store_id"]
            }
        ),
        Tool(
            name="get_b2b_profiles_and_identities_by_store_id",
            description="Get B2B profiles and identities for a given store ID",
            inputSchema={
                "type": "object",
                "properties": {
                    "store_id": {
                        "type": "string",
                        "description": "The store ID to lookup"
                    }
                },
                "required": ["store_id"]
            }
        ),
        Tool(
            name="onboard_user",
            description="Start the user onboarding process",
            inputSchema={
                "type": "object",
                "properties": {
                    "store_id": {"type": "string"},
                    "team_name": {"type": "string"},
                    "profile_name": {"type": "string"},
                    "selected_profiles": {
                        "type": "array",
                        "items": {"type": "string"}
                    },
                    "selected_identities": {
                        "type": "array",
                        "items": {"type": "string"}
                    }
                },
                "required": ["store_id", "team_name", "profile_name", "selected_profiles", "selected_identities"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle tool calls"""
    try:
        if name == "get_profile_and_team_name_by_store_id":
            store_id = arguments.get("store_id")
            if not store_id:
                raise ValueError("store_id is required")
            
            result = MCPTools.get_profile_and_team_name_by_store_id(store_id)
            return [TextContent(type="text", text=json.dumps(result))]
        
        elif name == "get_b2b_profiles_and_identities_by_store_id":
            store_id = arguments.get("store_id")
            if not store_id:
                raise ValueError("store_id is required")
            
            result = MCPTools.get_b2b_profiles_and_identities_by_store_id(store_id)
            return [TextContent(type="text", text=json.dumps(result))]
        
        elif name == "onboard_user":
            required_fields = ["store_id", "team_name", "profile_name", "selected_profiles", "selected_identities"]
            for field in required_fields:
                if field not in arguments:
                    raise ValueError(f"{field} is required")
            
            result = MCPTools.onboard_user(
                store_id=arguments["store_id"],
                team_name=arguments["team_name"],
                profile_name=arguments["profile_name"],
                selected_profiles=arguments["selected_profiles"],
                selected_identities=arguments["selected_identities"]
            )
            return [TextContent(type="text", text=json.dumps(result))]
        
        else:
            raise ValueError(f"Unknown tool: {name}")
    
    except Exception as e:
        logger.error(f"Error calling tool {name}: {str(e)}")
        return [TextContent(type="text", text=f"Error: {str(e)}")]

async def main():
    """Run the MCP server"""
    logger.info("Starting MCP Tools Server...")
    async with stdio_server() as streams:
        await server.run(streams[0], streams[1])

if __name__ == "__main__":
    asyncio.run(main())
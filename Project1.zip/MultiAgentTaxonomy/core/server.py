from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
import uvicorn
import agent_logic

app = FastAPI(title="Multi-Agent Taxonomy Service")

@app.post("/process_file")
async def process_file(file: UploadFile = File(...)):
    try:
        content = await file.read()
        filename = file.filename
        file_type = ""
        
        if filename.lower().endswith('.pdf'):
            file_type = "pdf"
        elif filename.lower().endswith('.xml'):
            file_type = "xml"
        else:
            # Try to guess or default?
            if b"%PDF" in content[:10]:
                file_type = "pdf"
            elif b"<?xml" in content[:10] or b"<" in content[:10]:
                file_type = "xml"
            else:
                raise HTTPException(status_code=400, detail="Unsupported file type. Please upload PDF or XML.")
        
        initial_state = {
            "filename": filename,
            "file_content": content,
            "file_type": file_type,
            "metadata": [],
            "final_output": None
        }
        
        result = agent_logic.app.invoke(initial_state)
        
        return result.get("final_output", {})
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

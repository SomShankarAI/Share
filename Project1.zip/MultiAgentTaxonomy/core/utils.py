import json
import os
from langchain_openai import ChatOpenAI

def load_taxonomy():
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        taxonomy_path = os.path.join(current_dir, "taxonomy-master.json")
        with open(taxonomy_path, "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading taxonomy: {e}")
        return []

TAXONOMY_MASTER = load_taxonomy()

def get_taxonomy_names():
    return [item["taxonomy"] for item in TAXONOMY_MASTER]

def get_taxonomy_details(name: str):
    for item in TAXONOMY_MASTER:
        if item["taxonomy"] == name:
            return item
    return None

def get_llm():
    # Assuming OPENAI_API_KEY is set in environment
    return ChatOpenAI(temperature=0, model="gpt-4o-mini")

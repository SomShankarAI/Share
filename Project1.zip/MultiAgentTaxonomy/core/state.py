from typing import TypedDict, List, Optional

class MetadataItem(TypedDict):
    taxonomy: str
    taxonomy_uri: str
    taxonomy_hierarchy: str
    text: str
    node: str

class AgentOutput(TypedDict):
    filename: str
    metadata: List[MetadataItem]

class AgentState(TypedDict):
    filename: str
    file_content: bytes  # Binary content
    file_type: str       # 'pdf' or 'xml'
    metadata: List[MetadataItem]
    final_output: Optional[AgentOutput]

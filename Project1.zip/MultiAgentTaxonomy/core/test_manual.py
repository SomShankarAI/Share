import sys
import os
# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agent_logic import app
from state import AgentState
from unittest.mock import MagicMock, patch

# Mock pypdf and ChatOpenAI to avoid dependencies/keys
with patch('pdf_agent.pypdf') as mock_pdf:
    with patch('utils.ChatOpenAI') as mock_llm_cls:
        print("Mocks setup")
        
        # Setup mock LLM response
        mock_llm_instance = MagicMock()
        mock_llm_cls.return_value = mock_llm_instance
        
        # Test PDF flow
        mock_response = MagicMock()
        mock_response.content = '{"taxonomy": "Test Tax", "taxonomy-uri": "uri", "taxonomy-hierarchy": "h", "text": "sample"}'
        mock_llm_instance.invoke.return_value = mock_response
        
        mock_pdf_reader = MagicMock()
        mock_pdf_reader.pages = [MagicMock()]
        mock_pdf_reader.pages[0].extract_text.return_value = "Sample PDF Text"
        mock_pdf.PdfReader.return_value = mock_pdf_reader

        initial_state = {
            "filename": "test.pdf",
            "file_content": b"%PDF-1.4...",
            "file_type": "pdf",
            "metadata": [],
            "final_output": None
        }
        
        print("Invoking graph with PDF...")
        try:
            result = app.invoke(initial_state)
            print("Graph invoked successfully")
            print("Result:", result.get("final_output"))
        except Exception as e:
            print(f"Graph invocation failed: {e}")

        # Test XML flow
        mock_response.content = '{"taxonomy": "XML Tax", "node": "/root/test"}'
        
        initial_state_xml = {
            "filename": "test.xml",
            "file_content": b"<root><test>Content</test></root>",
            "file_type": "xml",
            "metadata": [],
            "final_output": None
        }
        
        print("\nInvoking graph with XML...")
        try:
            result = app.invoke(initial_state_xml)
            print("Graph invoked successfully")
            print("Result:", result.get("final_output"))
        except Exception as e:
            print(f"Graph invocation failed: {e}")

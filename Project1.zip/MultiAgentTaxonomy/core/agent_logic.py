from typing import Dict
from langgraph.graph import StateGraph, END
from state import AgentState
from pdf_agent import pdf_agent
from xml_agent import xml_agent

# Output Formatter
def format_output(state: AgentState) -> Dict:
    output = {
        "filename": state["filename"],
        "metadata": state.get("metadata", [])
    }
    return {"final_output": output}

# Router Logic
def router(state: AgentState):
    file_type = state.get("file_type", "").lower()
    if file_type == "pdf":
        return "pdf_agent"
    elif file_type == "xml":
        return "xml_agent"
    else:
        # Fallback based on extension
        if state['filename'].lower().endswith('.pdf'):
            return "pdf_agent"
        elif state['filename'].lower().endswith('.xml'):
            return "xml_agent"
        # In a real app we might handle unknown types differently or query an LLM router
        return END

# Graph Construction
workflow = StateGraph(AgentState)

workflow.add_node("pdf_agent", pdf_agent)
workflow.add_node("xml_agent", xml_agent)
workflow.add_node("formatter", format_output)

workflow.set_conditional_entry_point(
    router,
    {
        "pdf_agent": "pdf_agent",
        "xml_agent": "xml_agent"
    }
)

workflow.add_edge("pdf_agent", "formatter")
workflow.add_edge("xml_agent", "formatter")
workflow.add_edge("formatter", END)

app = workflow.compile()

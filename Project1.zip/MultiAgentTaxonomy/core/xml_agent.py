import json
import xml.etree.ElementTree as ET
from typing import Dict
from langchain_core.messages import SystemMessage, HumanMessage
from state import AgentState, MetadataItem
from utils import get_llm, get_taxonomy_names, get_taxonomy_details

def xml_agent(state: AgentState) -> Dict:
    print(f"Processing XML: {state['filename']}")
    file_content = state['file_content']
    
    try:
        # Check validity
        ET.fromstring(file_content.decode('utf-8'))
        
        xml_str = file_content.decode('utf-8')[:4000]
        taxonomy_names = get_taxonomy_names()
        taxonomy_str = json.dumps(taxonomy_names, indent=2)
        
        prompt = f"""
        You are an expert taxonomy classifier.
        Here is the list of available taxonomy names:
        {taxonomy_str}
        
        Here is the content of an XML file named '{state['filename']}':
        {xml_str}
        
        Identify ALL relevant taxonomy names from the list for this document or specific nodes.
        Select the most representative node for each match.
        
        Return the result as a JSON object with a single key "matches", which is a list of objects.
        Each object should have:
        "taxonomy": <exact name from the list>,
        "node": <The XPath or tag path to the relevant element>,
        "text": <Leave empty>
        
        Return ONLY the JSON object.
        """
        
        llm = get_llm()
        messages = [
            SystemMessage(content="You are a helpful assistant that outputs JSON."),
            HumanMessage(content=prompt)
        ]
        
        response = llm.invoke(messages)
        content = response.content.strip()
        if content.startswith("```json"):
            content = content[7:]
        if content.endswith("```"):
            content = content[:-3]
            
        result = json.loads(content)
        matches = result.get("matches", [])
        if isinstance(matches, dict):
            matches = [matches]

        metadata_list = []
        for match in matches:
            tax_name = match.get("taxonomy", "")
            details = get_taxonomy_details(tax_name)
            
            tax_uri = details["taxonomy-uri"] if details else ""
            tax_hierarchy = details["taxonomy-hierarchy"] if details else ""
            
            meta_item: MetadataItem = {
                "taxonomy": tax_name,
                "taxonomy_uri": tax_uri,
                "taxonomy-hierarchy": tax_hierarchy,
                "text": "",
                "node": match.get("node", "")
            }
            metadata_list.append(meta_item)
        
        return {"metadata": metadata_list}

    except Exception as e:
        print(f"Error processing XML: {e}")
        return {"metadata": []}

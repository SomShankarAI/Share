# Multi-Agent Taxonomy Linker

This project is a multi-agent application that automatically links taxonomies to the content of PDF and XML files. It uses a core backend for processing and a Streamlit UI for user interaction.

## Prerequisites

- Python 3.9+
- OpenAI API Key (set as environment variable `OPENAI_API_KEY`)

## Installation

1.  **Clone the repository:**
    ```bash
    git clone <repository_url>
    cd MultiAgentTaxonomy
    ```

2.  **Install dependencies:**
    
    It is recommended to use a virtual environment.

    **Core/Backend Dependencies:**
    ```bash
    pip install -r requirements-core.txt
    ```

    **UI/Frontend Dependencies:**
    ```bash
    pip install -r requirements-ux.txt
    ```

## Running the Application

You need to run both the backend server and the frontend UI.

### 1. Start the Backend Server

Open a terminal and run:

```bash
python core/server.py
```

The server will start on `http://0.0.0.0:8000`.

### 2. Start the Frontend UI

Open a new terminal (in the project root) and run:

```bash
streamlit run ui/app.py
```

The application will open in your default browser, usually at `http://localhost:8501`.

## Usage

1.  Upload a PDF or XML file using the UI.
2.  Click "Process File".
3.  The system will analyze the file using the appropriate agent (PDF or XML) and identify relevant taxonomies based on the `taxonomy-master.json` file.
4.  Results will be displayed on the screen.

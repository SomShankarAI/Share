import streamlit as st
import requests
import json

st.set_page_config(page_title="Taxonomy Linker", layout="wide")

st.title("Multi-Agent Taxonomy Linker")
st.markdown("Upload a PDF or XML file to link it with the correct taxonomy.")

uploaded_file = st.file_uploader("Choose a file", type=["pdf", "xml"])

if uploaded_file is not None:
    st.info(f"File uploaded: {uploaded_file.name}")
    
    if st.button("Process File"):
        with st.spinner("Processing..."):
            try:
                files = {"file": (uploaded_file.name, uploaded_file, uploaded_file.type)}
                response = requests.post("http://localhost:8000/process_file", files=files)
                
                if response.status_code == 200:
                    result = response.json()
                    st.success("Processing Complete!")
                    st.subheader("Result")
                    st.json(result)
                    
                    # Optional: Pretty display
                    if "metadata" in result and result["metadata"]:
                         st.markdown("### Explained Metadata")
                         for item in result["metadata"]:
                             st.markdown(f"**Taxonomy:** {item.get('taxonomy')}")
                             st.markdown(f"**URI:** `{item.get('taxonomy_uri')}`")
                             st.markdown(f"**Hierarchy:** {item.get('taxonomy_hierarchy')}")
                             if item.get('text'):
                                 st.text_area("Extraction", item.get('text'), height=100)
                             if item.get('node'):
                                 st.code(item.get('node'), language="xml")
                             st.divider()
                else:
                    st.error(f"Error {response.status_code}: {response.text}")
            except requests.exceptions.ConnectionError:
                st.error("Could not connect to the backend server. Is it running on port 8000?")
            except Exception as e:
                st.error(f"An error occurred: {str(e)}")
